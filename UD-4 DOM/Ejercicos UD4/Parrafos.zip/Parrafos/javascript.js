// Fuente de información
const parrafo1 = {
    titulo: "Primer bloque de párrafos",
    hijos: ["primero", "segundo", "Tercero"]
}
const parrafo2 = {
    titulo: "Segundo bloque de párrafos",
    hijos: ["primero", "segundo", "Tercero"]
}

let contenedor = new Set([parrafo1,parrafo2])

contenedor.forEach(parrafo => {

    crearElemento("h1", parrafo.titulo, document.body)

    //AÑADO los HIJOS
    parrafo.hijos.forEach(e => {
        crearElemento("p", e, document.body)
    })

})

function crearElemento(tipo, contenido, padre) {
    // Crear el elemento del tipo especificado
    let hijo = document.createElement(tipo)
    // Indicamos el contenido
    hijo.innerHTML = contenido
    //añadir el nodo al documento
    padre.appendChild(hijo)

    hijo.addEventListener("click",function(){
        this.remove()
    })
    
}


